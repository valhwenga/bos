import React from "react";
import Placeholder from "@/pages/Placeholder";
const Taxes: React.FC = () => <Placeholder />;
export default Taxes;
